#include "BookingService.h"
#include <algorithm>
#include <stdexcept>

BookingService& BookingService::getInstance() {
    static BookingService instance;
    return instance;
}

void BookingService::addCinema(std::shared_ptr<Cinema> cinema) {
    std::lock_guard<std::mutex> lock(serviceMutex);
    cinemas.push_back(std::move(cinema));
}

void BookingService::addShow(std::shared_ptr<Show> show) {
    std::lock_guard<std::mutex> lock(serviceMutex);
    const std::string showId = show->getId();

    // Generate one ShowSeat per physical seat on the screen for this show.
    std::vector<std::shared_ptr<ShowSeat>> seatsForShow;
    for (const auto& seat : show->getScreen()->getSeats()) {
        seatsForShow.push_back(std::make_shared<ShowSeat>(seat, show));
    }

    showSeatsMap[showId] = std::move(seatsForShow);
    shows[showId] = std::move(show);
}

std::vector<std::shared_ptr<Show>> BookingService::getShowsForMovie(const std::string& movieId) const {
    std::lock_guard<std::mutex> lock(serviceMutex);
    std::vector<std::shared_ptr<Show>> result;
    for (const auto& [id, show] : shows) {
        if (show->getMovie()->getId() == movieId) {
            result.push_back(show);
        }
    }
    return result;
}

std::vector<std::shared_ptr<ShowSeat>> BookingService::getAvailableSeats(const std::string& showId) const {
    std::lock_guard<std::mutex> lock(serviceMutex);
    std::vector<std::shared_ptr<ShowSeat>> result;
    auto it = showSeatsMap.find(showId);
    if (it == showSeatsMap.end()) return result;

    for (const auto& seat : it->second) {
        if (seat->getStatus() == SeatStatus::AVAILABLE) {
            result.push_back(seat);
        }
    }
    return result;
}

std::string BookingService::generateBookingId() {
    return "BKG" + std::to_string(++bookingCounter);
}

std::shared_ptr<Booking> BookingService::createBooking(const std::shared_ptr<Customer>& customer,
                                                         const std::string& showId,
                                                         const std::vector<std::string>& seatIds) {
    std::lock_guard<std::mutex> lock(serviceMutex);

    auto showIt = shows.find(showId);
    if (showIt == shows.end()) return nullptr;

    auto& allSeats = showSeatsMap[showId];
    std::vector<std::shared_ptr<ShowSeat>> requestedSeats;

    for (const auto& seatId : seatIds) {
        auto found = std::find_if(allSeats.begin(), allSeats.end(),
            [&](const std::shared_ptr<ShowSeat>& s) { return s->getSeat()->getId() == seatId; });

        if (found == allSeats.end()) return nullptr; // seat doesn't exist for this show

        std::lock_guard<std::mutex> seatLock((*found)->getMutex());
        if ((*found)->getStatus() != SeatStatus::AVAILABLE) {
            return nullptr; // someone else already holds/booked this seat
        }
        requestedSeats.push_back(*found);
    }

    // Lock all requested seats now that we know they're all free.
    for (auto& seat : requestedSeats) {
        std::lock_guard<std::mutex> seatLock(seat->getMutex());
        seat->setStatus(SeatStatus::LOCKED);
    }

    std::string bookingId = generateBookingId();
    auto booking = std::make_shared<Booking>(bookingId, customer, showIt->second);
    for (auto& seat : requestedSeats) {
        booking->addSeat(seat);
    }

    bookings[bookingId] = booking;
    return booking;
}

bool BookingService::confirmBooking(const std::string& bookingId, std::shared_ptr<Payment> payment) {
    std::shared_ptr<Booking> booking;
    {
        std::lock_guard<std::mutex> lock(serviceMutex);
        auto it = bookings.find(bookingId);
        if (it == bookings.end()) return false;
        booking = it->second;
    }

    if (booking->getStatus() != BookingStatus::CREATED) return false;

    bool paid = payment->processPayment();
    if (!paid) {
        cancelBooking(bookingId);
        return false;
    }

    booking->setPayment(payment);
    booking->confirm();
    return true;
}

void BookingService::cancelBooking(const std::string& bookingId) {
    std::lock_guard<std::mutex> lock(serviceMutex);
    auto it = bookings.find(bookingId);
    if (it == bookings.end()) return;
    it->second->cancel();
}

std::shared_ptr<Booking> BookingService::getBooking(const std::string& bookingId) const {
    std::lock_guard<std::mutex> lock(serviceMutex);
    auto it = bookings.find(bookingId);
    return it != bookings.end() ? it->second : nullptr;
}
