#include "Movie.h"

Movie::Movie(std::string id, std::string title, int durationMinutes,
             std::string genre, std::string language)
    : id(std::move(id)), title(std::move(title)),
      durationMinutes(durationMinutes), genre(std::move(genre)),
      language(std::move(language)) {}

std::string Movie::getId() const { return id; }
std::string Movie::getTitle() const { return title; }
int Movie::getDurationMinutes() const { return durationMinutes; }
std::string Movie::getGenre() const { return genre; }
std::string Movie::getLanguage() const { return language; }
