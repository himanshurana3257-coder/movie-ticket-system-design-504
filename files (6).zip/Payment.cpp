#include "Payment.h"

std::string paymentStatusToString(PaymentStatus status) {
    switch (status) {
        case PaymentStatus::PENDING: return "PENDING";
        case PaymentStatus::SUCCESS: return "SUCCESS";
        case PaymentStatus::FAILED: return "FAILED";
    }
    return "UNKNOWN";
}

Payment::Payment(std::string id, double amount)
    : id(std::move(id)), amount(amount), status(PaymentStatus::PENDING) {}

std::string Payment::getId() const { return id; }
double Payment::getAmount() const { return amount; }
PaymentStatus Payment::getStatus() const { return status; }
