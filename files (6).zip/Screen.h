#ifndef SCREEN_H
#define SCREEN_H

#include <string>
#include <vector>
#include <memory>
#include "Seat.h"

class Screen {
public:
    Screen(std::string id, std::string name);

    void addSeat(std::shared_ptr<Seat> seat);
    std::vector<std::shared_ptr<Seat>> getSeats() const;

    std::string getId() const;
    std::string getName() const;

private:
    std::string id;
    std::string name;
    std::vector<std::shared_ptr<Seat>> seats;
};

#endif // SCREEN_H
