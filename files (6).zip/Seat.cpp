#include "Seat.h"

std::string seatTypeToString(SeatType type) {
    switch (type) {
        case SeatType::SILVER: return "SILVER";
        case SeatType::GOLD: return "GOLD";
        case SeatType::PLATINUM: return "PLATINUM";
    }
    return "UNKNOWN";
}

Seat::Seat(std::string id, int row, int number, SeatType type)
    : id(std::move(id)), row(row), number(number), type(type) {}

std::string Seat::getId() const { return id; }
int Seat::getRow() const { return row; }
int Seat::getNumber() const { return number; }
SeatType Seat::getType() const { return type; }
