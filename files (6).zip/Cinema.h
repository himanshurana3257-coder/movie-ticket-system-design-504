#ifndef CINEMA_H
#define CINEMA_H

#include <string>
#include <vector>
#include <memory>
#include "Screen.h"

class Cinema {
public:
    Cinema(std::string id, std::string name, std::string location);

    void addScreen(std::shared_ptr<Screen> screen);
    std::vector<std::shared_ptr<Screen>> getScreens() const;

    std::string getId() const;
    std::string getName() const;
    std::string getLocation() const;

private:
    std::string id;
    std::string name;
    std::string location;
    std::vector<std::shared_ptr<Screen>> screens;
};

#endif // CINEMA_H
