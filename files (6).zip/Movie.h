#ifndef MOVIE_H
#define MOVIE_H

#include <string>

class Movie {
public:
    Movie(std::string id, std::string title, int durationMinutes,
          std::string genre, std::string language);

    std::string getId() const;
    std::string getTitle() const;
    int getDurationMinutes() const;
    std::string getGenre() const;
    std::string getLanguage() const;

private:
    std::string id;
    std::string title;
    int durationMinutes;
    std::string genre;
    std::string language;
};

#endif // MOVIE_H
