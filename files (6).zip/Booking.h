#ifndef BOOKING_H
#define BOOKING_H

#include <string>
#include <vector>
#include <memory>
#include "Customer.h"
#include "Show.h"
#include "ShowSeat.h"
#include "Payment.h"

enum class BookingStatus { CREATED, CONFIRMED, CANCELLED, EXPIRED };

std::string bookingStatusToString(BookingStatus status);

class Booking {
public:
    Booking(std::string id, std::shared_ptr<Customer> customer, std::shared_ptr<Show> show);

    void addSeat(std::shared_ptr<ShowSeat> seat);
    void setPayment(std::shared_ptr<Payment> payment);

    void confirm();
    void cancel();

    std::string getId() const;
    std::shared_ptr<Customer> getCustomer() const;
    std::shared_ptr<Show> getShow() const;
    std::vector<std::shared_ptr<ShowSeat>> getSeats() const;
    std::shared_ptr<Payment> getPayment() const;
    BookingStatus getStatus() const;
    double getTotalAmount() const;

private:
    std::string id;
    std::shared_ptr<Customer> customer;
    std::shared_ptr<Show> show;
    std::vector<std::shared_ptr<ShowSeat>> seats;
    std::shared_ptr<Payment> payment;
    BookingStatus status;
};

#endif // BOOKING_H
