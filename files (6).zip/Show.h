#ifndef SHOW_H
#define SHOW_H

#include <string>
#include <ctime>
#include <map>
#include <memory>
#include "Movie.h"
#include "Screen.h"
#include "Seat.h"

class Show {
public:
    Show(std::string id, std::shared_ptr<Movie> movie,
         std::shared_ptr<Screen> screen, time_t startTime, time_t endTime);

    void setPrice(SeatType type, double price);
    double getPrice(SeatType type) const;

    std::string getId() const;
    std::shared_ptr<Movie> getMovie() const;
    std::shared_ptr<Screen> getScreen() const;
    time_t getStartTime() const;
    time_t getEndTime() const;

private:
    std::string id;
    std::shared_ptr<Movie> movie;
    std::shared_ptr<Screen> screen;
    time_t startTime;
    time_t endTime;
    std::map<SeatType, double> priceMap;
};

#endif // SHOW_H
