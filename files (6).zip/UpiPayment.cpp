#include "UpiPayment.h"
#include <iostream>

UpiPayment::UpiPayment(std::string id, double amount, std::string upiId)
    : Payment(std::move(id), amount), upiId(std::move(upiId)) {}

bool UpiPayment::processPayment() {
    // Simulated UPI payment gateway call.
    std::cout << "Processing UPI payment of Rs. " << amount
              << " via UPI ID: " << upiId << "...\n";

    // In a real system this would call an external gateway/bank API.
    status = PaymentStatus::SUCCESS;
    std::cout << "Payment " << id << " status: "
              << paymentStatusToString(status) << "\n";
    return status == PaymentStatus::SUCCESS;
}

std::string UpiPayment::getUpiId() const { return upiId; }
