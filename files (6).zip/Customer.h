#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>

class Customer {
public:
    Customer(std::string id, std::string name, std::string email, std::string phone);

    std::string getId() const;
    std::string getName() const;
    std::string getEmail() const;
    std::string getPhone() const;

private:
    std::string id;
    std::string name;
    std::string email;
    std::string phone;
};

#endif // CUSTOMER_H
