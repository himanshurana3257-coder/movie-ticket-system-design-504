#include <iostream>
#include <memory>
#include <ctime>
#include "Movie.h"
#include "Seat.h"
#include "Screen.h"
#include "Cinema.h"
#include "Show.h"
#include "ShowSeat.h"
#include "Customer.h"
#include "Booking.h"
#include "Payment.h"
#include "UpiPayment.h"
#include "BookingService.h"

int main() {
    BookingService& service = BookingService::getInstance();

    // ---- Set up movie ----
    auto movie = std::make_shared<Movie>("M1", "Interstellar", 169, "Sci-Fi", "English");

    // ---- Set up cinema, screen and seats ----
    auto screen = std::make_shared<Screen>("SCR1", "Screen 1");
    for (int row = 1; row <= 3; ++row) {
        for (int num = 1; num <= 5; ++num) {
            SeatType type = (row == 1) ? SeatType::PLATINUM
                          : (row == 2) ? SeatType::GOLD
                                       : SeatType::SILVER;
            std::string seatId = "R" + std::to_string(row) + "N" + std::to_string(num);
            screen->addSeat(std::make_shared<Seat>(seatId, row, num, type));
        }
    }

    auto cinema = std::make_shared<Cinema>("C1", "PVR Cinemas", "Dehradun");
    cinema->addScreen(screen);
    service.addCinema(cinema);

    // ---- Set up a show ----
    time_t now = time(nullptr);
    auto show = std::make_shared<Show>("SH1", movie, screen, now, now + 169 * 60);
    show->setPrice(SeatType::SILVER, 150.0);
    show->setPrice(SeatType::GOLD, 250.0);
    show->setPrice(SeatType::PLATINUM, 400.0);
    service.addShow(show);

    // ---- Customer browses shows for a movie ----
    std::cout << "Shows available for '" << movie->getTitle() << "':\n";
    for (const auto& s : service.getShowsForMovie(movie->getId())) {
        std::cout << " - Show " << s->getId() << " on screen "
                  << s->getScreen()->getName() << "\n";
    }

    std::cout << "\nAvailable seats for show SH1: "
              << service.getAvailableSeats("SH1").size() << "\n\n";

    // ---- Customer creates a booking ----
    auto customer = std::make_shared<Customer>("CUST1", "Asha Rao", "asha@example.com", "9999999999");

    auto booking = service.createBooking(customer, "SH1", {"R1N1", "R1N2"});
    if (!booking) {
        std::cout << "Could not create booking - seats unavailable.\n";
        return 1;
    }

    std::cout << "Booking " << booking->getId() << " created for "
              << customer->getName() << ", total amount: Rs. "
              << booking->getTotalAmount() << "\n\n";

    // ---- Pay and confirm ----
    auto payment = std::make_shared<UpiPayment>("PAY1", booking->getTotalAmount(), "asha@upi");
    bool success = service.confirmBooking(booking->getId(), payment);

    if (success) {
        std::cout << "\nBooking " << booking->getId() << " status: "
                  << bookingStatusToString(booking->getStatus()) << "\n";
        std::cout << "Booked seats:\n";
        for (const auto& seat : booking->getSeats()) {
            std::cout << " - " << seat->getSeat()->getId()
                      << " (" << seatTypeToString(seat->getSeat()->getType()) << ") : "
                      << seatStatusToString(seat->getStatus()) << "\n";
        }
    } else {
        std::cout << "Payment failed, booking cancelled.\n";
    }

    std::cout << "\nRemaining available seats for show SH1: "
              << service.getAvailableSeats("SH1").size() << "\n";

    return 0;
}
