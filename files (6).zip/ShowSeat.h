#ifndef SHOWSEAT_H
#define SHOWSEAT_H

#include <string>
#include <memory>
#include <mutex>
#include "Seat.h"
#include "Show.h"

enum class SeatStatus { AVAILABLE, LOCKED, BOOKED };

std::string seatStatusToString(SeatStatus status);

// Represents one physical seat for one specific show.
class ShowSeat {
public:
    ShowSeat(std::shared_ptr<Seat> seat, std::shared_ptr<Show> show);

    std::string getShowSeatId() const;
    std::shared_ptr<Seat> getSeat() const;
    std::shared_ptr<Show> getShow() const;
    double getPrice() const;

    SeatStatus getStatus() const;
    void setStatus(SeatStatus status);

    // Used by BookingService to guard against double booking.
    std::mutex& getMutex();

private:
    std::shared_ptr<Seat> seat;
    std::shared_ptr<Show> show;
    SeatStatus status;
    std::mutex seatMutex;
};

#endif // SHOWSEAT_H
