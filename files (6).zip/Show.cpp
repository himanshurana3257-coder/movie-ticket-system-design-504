#include "Show.h"

Show::Show(std::string id, std::shared_ptr<Movie> movie,
           std::shared_ptr<Screen> screen, time_t startTime, time_t endTime)
    : id(std::move(id)), movie(std::move(movie)), screen(std::move(screen)),
      startTime(startTime), endTime(endTime) {}

void Show::setPrice(SeatType type, double price) { priceMap[type] = price; }

double Show::getPrice(SeatType type) const {
    auto it = priceMap.find(type);
    return it != priceMap.end() ? it->second : 0.0;
}

std::string Show::getId() const { return id; }
std::shared_ptr<Movie> Show::getMovie() const { return movie; }
std::shared_ptr<Screen> Show::getScreen() const { return screen; }
time_t Show::getStartTime() const { return startTime; }
time_t Show::getEndTime() const { return endTime; }
