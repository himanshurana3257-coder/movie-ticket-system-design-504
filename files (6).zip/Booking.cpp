#include "Booking.h"

std::string bookingStatusToString(BookingStatus status) {
    switch (status) {
        case BookingStatus::CREATED: return "CREATED";
        case BookingStatus::CONFIRMED: return "CONFIRMED";
        case BookingStatus::CANCELLED: return "CANCELLED";
        case BookingStatus::EXPIRED: return "EXPIRED";
    }
    return "UNKNOWN";
}

Booking::Booking(std::string id, std::shared_ptr<Customer> customer, std::shared_ptr<Show> show)
    : id(std::move(id)), customer(std::move(customer)), show(std::move(show)),
      status(BookingStatus::CREATED) {}

void Booking::addSeat(std::shared_ptr<ShowSeat> seat) {
    seats.push_back(std::move(seat));
}

void Booking::setPayment(std::shared_ptr<Payment> newPayment) {
    payment = std::move(newPayment);
}

void Booking::confirm() {
    for (auto& seat : seats) {
        seat->setStatus(SeatStatus::BOOKED);
    }
    status = BookingStatus::CONFIRMED;
}

void Booking::cancel() {
    for (auto& seat : seats) {
        seat->setStatus(SeatStatus::AVAILABLE);
    }
    status = BookingStatus::CANCELLED;
}

std::string Booking::getId() const { return id; }
std::shared_ptr<Customer> Booking::getCustomer() const { return customer; }
std::shared_ptr<Show> Booking::getShow() const { return show; }
std::vector<std::shared_ptr<ShowSeat>> Booking::getSeats() const { return seats; }
std::shared_ptr<Payment> Booking::getPayment() const { return payment; }
BookingStatus Booking::getStatus() const { return status; }

double Booking::getTotalAmount() const {
    double total = 0.0;
    for (const auto& seat : seats) {
        total += seat->getPrice();
    }
    return total;
}
