#ifndef SEAT_H
#define SEAT_H

#include <string>

enum class SeatType { SILVER, GOLD, PLATINUM };

std::string seatTypeToString(SeatType type);

class Seat {
public:
    Seat(std::string id, int row, int number, SeatType type);

    std::string getId() const;
    int getRow() const;
    int getNumber() const;
    SeatType getType() const;

private:
    std::string id;
    int row;
    int number;
    SeatType type;
};

#endif // SEAT_H
