#ifndef BOOKINGSERVICE_H
#define BOOKINGSERVICE_H

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <mutex>
#include "Cinema.h"
#include "Movie.h"
#include "Show.h"
#include "ShowSeat.h"
#include "Customer.h"
#include "Booking.h"
#include "Payment.h"

// Singleton facade that coordinates cinemas, shows, seats and bookings.
class BookingService {
public:
    static BookingService& getInstance();

    BookingService(const BookingService&) = delete;
    BookingService& operator=(const BookingService&) = delete;

    void addCinema(std::shared_ptr<Cinema> cinema);
    void addShow(std::shared_ptr<Show> show);

    std::vector<std::shared_ptr<Show>> getShowsForMovie(const std::string& movieId) const;
    std::vector<std::shared_ptr<ShowSeat>> getAvailableSeats(const std::string& showId) const;

    // Creates a CREATED booking and locks the requested seats.
    // Returns nullptr if any seat is unavailable.
    std::shared_ptr<Booking> createBooking(const std::shared_ptr<Customer>& customer,
                                            const std::string& showId,
                                            const std::vector<std::string>& seatIds);

    // Charges payment and confirms the booking, or releases the seats on failure.
    bool confirmBooking(const std::string& bookingId, std::shared_ptr<Payment> payment);

    void cancelBooking(const std::string& bookingId);

    std::shared_ptr<Booking> getBooking(const std::string& bookingId) const;

private:
    BookingService() = default;

    std::string generateBookingId();

    std::vector<std::shared_ptr<Cinema>> cinemas;
    std::map<std::string, std::shared_ptr<Show>> shows;                          // showId -> Show
    std::map<std::string, std::vector<std::shared_ptr<ShowSeat>>> showSeatsMap;  // showId -> seats
    std::map<std::string, std::shared_ptr<Booking>> bookings;                    // bookingId -> Booking

    mutable std::mutex serviceMutex;
    int bookingCounter = 0;
};

#endif // BOOKINGSERVICE_H
