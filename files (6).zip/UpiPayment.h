#ifndef UPIPAYMENT_H
#define UPIPAYMENT_H

#include "Payment.h"
#include <string>

class UpiPayment : public Payment {
public:
    UpiPayment(std::string id, double amount, std::string upiId);

    bool processPayment() override;

    std::string getUpiId() const;

private:
    std::string upiId;
};

#endif // UPIPAYMENT_H
