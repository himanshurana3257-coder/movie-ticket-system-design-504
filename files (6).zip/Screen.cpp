#include "Screen.h"

Screen::Screen(std::string id, std::string name)
    : id(std::move(id)), name(std::move(name)) {}

void Screen::addSeat(std::shared_ptr<Seat> seat) {
    seats.push_back(std::move(seat));
}

std::vector<std::shared_ptr<Seat>> Screen::getSeats() const { return seats; }

std::string Screen::getId() const { return id; }
std::string Screen::getName() const { return name; }
