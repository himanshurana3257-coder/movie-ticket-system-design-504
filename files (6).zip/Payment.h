#ifndef PAYMENT_H
#define PAYMENT_H

#include <string>

enum class PaymentStatus { PENDING, SUCCESS, FAILED };

std::string paymentStatusToString(PaymentStatus status);

// Abstract base class - Strategy pattern for different payment methods.
class Payment {
public:
    Payment(std::string id, double amount);
    virtual ~Payment() = default;

    virtual bool processPayment() = 0;

    std::string getId() const;
    double getAmount() const;
    PaymentStatus getStatus() const;

protected:
    std::string id;
    double amount;
    PaymentStatus status;
};

#endif // PAYMENT_H
