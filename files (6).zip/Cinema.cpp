#include "Cinema.h"

Cinema::Cinema(std::string id, std::string name, std::string location)
    : id(std::move(id)), name(std::move(name)), location(std::move(location)) {}

void Cinema::addScreen(std::shared_ptr<Screen> screen) {
    screens.push_back(std::move(screen));
}

std::vector<std::shared_ptr<Screen>> Cinema::getScreens() const { return screens; }

std::string Cinema::getId() const { return id; }
std::string Cinema::getName() const { return name; }
std::string Cinema::getLocation() const { return location; }
