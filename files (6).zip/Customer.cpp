#include "Customer.h"

Customer::Customer(std::string id, std::string name, std::string email, std::string phone)
    : id(std::move(id)), name(std::move(name)), email(std::move(email)), phone(std::move(phone)) {}

std::string Customer::getId() const { return id; }
std::string Customer::getName() const { return name; }
std::string Customer::getEmail() const { return email; }
std::string Customer::getPhone() const { return phone; }
