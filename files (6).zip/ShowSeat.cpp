#include "ShowSeat.h"

std::string seatStatusToString(SeatStatus status) {
    switch (status) {
        case SeatStatus::AVAILABLE: return "AVAILABLE";
        case SeatStatus::LOCKED: return "LOCKED";
        case SeatStatus::BOOKED: return "BOOKED";
    }
    return "UNKNOWN";
}

ShowSeat::ShowSeat(std::shared_ptr<Seat> seat, std::shared_ptr<Show> show)
    : seat(std::move(seat)), show(std::move(show)), status(SeatStatus::AVAILABLE) {}

std::string ShowSeat::getShowSeatId() const {
    return show->getId() + "_" + seat->getId();
}

std::shared_ptr<Seat> ShowSeat::getSeat() const { return seat; }
std::shared_ptr<Show> ShowSeat::getShow() const { return show; }

double ShowSeat::getPrice() const { return show->getPrice(seat->getType()); }

SeatStatus ShowSeat::getStatus() const { return status; }
void ShowSeat::setStatus(SeatStatus newStatus) { status = newStatus; }

std::mutex& ShowSeat::getMutex() { return seatMutex; }
